function cars(){
let Bmw = {
    marka : 'Bmw',
    model : 'M3',
    color : 'gray',
    full(){
        console.log(this.marka + this.model + this.color)
     }
  
}
}

let Mercedes = {
    marka : 'Mercedes',
    model : 'A-class',
    color : 'gray', 
    full(){
       console.log(this.marka + this.model + this.color)
    }
}
Mercedes.full();

let Bmw = {
    marka : 'Bmw',
    model : 'M3',
    color : 'gray',
    full(){
        console.log(this.marka + this.model + this.color)
    }
    
}

Bmw.full();




